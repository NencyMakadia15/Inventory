﻿using System.ComponentModel.DataAnnotations;

namespace InventoryTask.Models
{
    public class Inventory
    {
        public string ProductCode { get; set; }
        public double EventType { get; set; }
        public double Quantity { get; set; }
        public double Price { get; set; }
        [DisplayFormat(DataFormatString = "{0:MM/yyyy}")]
        public DateTime Date { get; set; }
        
    }
}
