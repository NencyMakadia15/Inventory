﻿using ExcelDataReader;
using InventoryTask.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.PortableExecutable;

namespace InventoryTask.Controllers
{
    public class InventoryController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new List<InventoryVM>());
        }
        [HttpPost]
        public IActionResult Index(IFormCollection form)
        {
            List<Inventory> invents = new List<Inventory>();
            var fileName = "./inevtoryTask (1).xlsx";

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = System.IO.File.Open(fileName, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    while (reader.Read())
                    {
                        invents.Add(new Inventory
                        {
                            ProductCode = reader.GetString(0),
                            EventType = reader.GetDouble(1),
                            Quantity = reader.GetDouble(2),
                            Price = reader.GetDouble(3),
                            Date = reader.GetDateTime(4)
                        });
                    }
                }
            }

            List<InventoryVM> inventories = new List<InventoryVM>();
            var col = new InventoryVM(); 
            var data = invents.GroupBy(x => x.Date.Month).ToList();

            foreach (var month in data)
            {

                var p = month.GroupBy(x => x.ProductCode).ToList();

                foreach (var product in p)
                {
                    
                    col.TotalPurchaseQuantity = 0;
                    col.TotalSaleQuantity = 0;
                    col.TotalPurchaseAmount = 0;
                    col.TotalSaleAmount = 0;
                    col.ProfitOrLoss = 0;
                    col.PurchasePrice = 0;
                    col.SalePrice = 0;
                    col.ClosingQuantity = 0;
                    int count = 1;
                    int count1 = 1;
                    foreach (var item in product)
                    {
                        var var = inventories.LastOrDefault(x => x.ProductCode == item.ProductCode);
                        if(var != null)
                        {
                            if (item.EventType == 1 && count>0)
                            {
                                col.TotalPurchaseQuantity += item.Quantity;
                                col.TotalPurchaseAmount += (item.Quantity * item.Price);
                                col.PurchasePrice += item.Price;
                                col.Count = count;
                                col.AvgPurchasePrice = (col.PurchasePrice / col.Count);
                                count++;
                                
                            }
                            if (item.EventType == 2 && count1>0)
                            {
                                col.TotalSaleQuantity += item.Quantity;
                                col.TotalSaleAmount += (item.Quantity * item.Price);
                                col.SalePrice += item.Price;
                                col.Count1 = count1;
                                col.AvgSalePrice = (col.SalePrice / col.Count1);
                                count1++;
                            }
                            col.OpeningQuantity = var.ClosingQuantity;
                            col.ClosingQuantity = col.OpeningQuantity + (col.TotalPurchaseQuantity - col.TotalSaleQuantity);
                            
                        }
                        else
                        {
                            if (item.EventType == 1 && count > 0)
                            {
                                col.TotalPurchaseQuantity += item.Quantity;
                                col.TotalPurchaseAmount += (item.Quantity * item.Price);
                                col.PurchasePrice += item.Price; 
                                col.Count = count;
                                col.AvgPurchasePrice = (col.PurchasePrice / col.Count);
                                count++;
                            }
                            if (item.EventType == 2 && count1 > 0)
                            {
                                col.TotalSaleQuantity += item.Quantity;
                                col.TotalSaleAmount += (item.Quantity * item.Price);
                                col.SalePrice += item.Price;
                                col.Count1 = count1;
                                col.AvgSalePrice = (col.SalePrice / col.Count1);
                                count1++;
                            }
                            col.ClosingQuantity = (col.TotalPurchaseQuantity - col.TotalSaleQuantity);
                        }
                        col.ProfitOrLoss = (int)(col.TotalSaleQuantity * (col.AvgSalePrice - col.AvgPurchasePrice));
                        col.ProductCode = item.ProductCode;
                        col.Date = item.Date;
                        
                    }
                    inventories.Add(new InventoryVM
                    {
                        ProductCode = col.ProductCode,
                        Date = col.Date,
                        TotalPurchaseAmount = col.TotalPurchaseAmount,
                        TotalSaleAmount= col.TotalSaleAmount,
                        TotalPurchaseQuantity = col.TotalPurchaseQuantity,
                        TotalSaleQuantity = col.TotalSaleQuantity,
                        ProfitOrLoss = col.ProfitOrLoss,
                        ClosingQuantity = col.ClosingQuantity,
                        OpeningQuantity = col.OpeningQuantity
                    });

                }

            }
            return View(inventories);
        }
    }
}
