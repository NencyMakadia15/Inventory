﻿using System.ComponentModel.DataAnnotations;

namespace InventoryTask.Models
{
    public class InventoryVM
    {
        public string ProductCode { get; set; }
        public double EventType { get; set; }
        public double Quantity { get; set; }
        public double Price { get; set; }
        [DisplayFormat(DataFormatString = "{0:MM/yyyy}")]
        public DateTime Date { get; set; }
        public double TotalPurchaseQuantity { get; set; }
        
        public double TotalPurchaseAmount { get; set; }
        public double TotalSaleQuantity { get; set; }
        public double TotalSaleAmount { get; set; }
        public double ProfitOrLoss { get; set; }
        public double ClosingQuantity { get; set; }
        public double OpeningQuantity { get; set; }
        public double PurchasePrice { get; set; }
        public double SalePrice { get; set; }
        public int Count { get; set; }
        public int Count1 { get; set; }
        public double AvgPurchasePrice { get; set; }
        public double AvgSalePrice { get; set; }
    }
}
